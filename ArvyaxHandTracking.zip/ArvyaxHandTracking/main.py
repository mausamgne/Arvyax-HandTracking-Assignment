import cv2
import numpy as np

WINDOW_NAME = "Arvyax Prototype - Hand Tracking"

def point_to_rect_distance(px, py, x1, y1, x2, y2):
    dx = max(x1 - px, 0, px - x2)
    dy = max(y1 - py, 0, py - y2)
    return (dx*dx + dy*dy)**0.5


cap = cv2.VideoCapture(0)

cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
cv2.resizeWindow(WINDOW_NAME, 1100, 600)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    h, w, _ = frame.shape

    # ⭐ Crop 70% to remove entire face + body
    roi = frame[int(h * 0.70):h, 0:w]

    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

    lower = np.array([0, 30, 60])
    upper = np.array([20, 150, 255])
    mask = cv2.inRange(hsv, lower, upper)

    mask = cv2.GaussianBlur(mask, (7,7), 0)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    hand_center = None
    valid_contour_found = False

    roi_h, roi_w, _ = roi.shape
    rect_x1 = int(roi_w * 0.30)
    rect_y1 = int(roi_h * 0.10)
    rect_x2 = int(roi_w * 0.70)
    rect_y2 = int(roi_h * 0.70)

    # Detect valid hand contour
    for c in contours:
        area = cv2.contourArea(c)
        
        # ⭐ IGNORE ANYTHING SMALLER THAN A HAND
        if 9000 < area < 200000:
            valid_contour_found = True
            cv2.drawContours(roi, [c], -1, (0,255,0), 2)

            M = cv2.moments(c)
            if M["m00"] != 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                hand_center = (cx, cy)
                cv2.circle(roi, hand_center, 7, (0,0,255), -1)
            break

    cv2.rectangle(roi, (rect_x1, rect_y1), (rect_x2, rect_y2), (255,0,0), 2)

    # -----------------------
    # ⭐ FINAL SAFE LOGIC
    # -----------------------
    state = "SAFE"
    color = (0,255,0)

    if not valid_contour_found:
        # No hand = SAFE!
        state = "SAFE"
        color = (0,255,0)

    elif hand_center:
        distance = point_to_rect_distance(hand_center[0], hand_center[1],
                                          rect_x1, rect_y1, rect_x2, rect_y2)

        if distance > 160:
            state = "SAFE"
            color = (0,255,0)

        elif distance > 60:
            state = "WARNING"
            color = (0,255,255)

        else:
            state = "DANGER"
            color = (0,0,255)
            cv2.putText(roi, "DANGER DANGER!", (30,70),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.4, (0,0,255), 4)

    cv2.putText(roi, state, (20,35),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, color, 3)

    cv2.imshow(WINDOW_NAME, roi)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
